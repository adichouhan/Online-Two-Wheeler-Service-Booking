-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2018 at 02:52 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tws`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `id` int(11) NOT NULL,
  `Address` text NOT NULL,
  `addresstype` int(2) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `Address`, `addresstype`, `uid`) VALUES
(1, 'sdadasdadasda', 1, 4),
(2, '22,baldota,house,matunga', 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `addresstype`
--

CREATE TABLE `addresstype` (
  `id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addresstype`
--

INSERT INTO `addresstype` (`id`, `type`) VALUES
(1, 'Home'),
(2, 'Office');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `comments` text NOT NULL,
  `submitted_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `email`, `phone`, `comments`, `submitted_at`) VALUES
('HT', 'qqq@das.com', '1234567890', 'WEDS', '2017-05-03 18:29:21'),
('Ht', 'hthakkar8@gmail.com', '1234567890', 'Jsad', '2017-05-03 18:37:38'),
('Ht', 'hthakkar8@gmail.com', '1234567890', 'Jsad', '2017-05-03 18:37:52'),
('Ht', 'hthakkar8@gmail.com', '1234567890', '213w', '2017-05-03 18:38:08'),
('Ht', 'hthallar8@gmail.com', '1234567890', '12', '2017-05-03 18:42:51'),
('Ht', 'hthallar8@gmail.com', '1234567890', '312', '2017-05-03 18:44:49'),
('Ht', 'hthallar8@gmail.com', '1234567890', '312', '2017-05-03 18:46:13'),
('Ht', 'hthallar8@gmail.com', '1234567890', '1', '2017-05-03 18:46:29'),
('Ht', 'hthallar8@gmail.com', '1234567890', '1', '2017-05-03 18:47:36'),
('Ht', 'hthallar8@gmail.com', '1234567890', '1w21', '2017-05-03 18:48:39'),
('Ht', 'hthallar8@gmail.com', '1234567890', '213', '2017-05-03 18:51:28'),
('Ht', 'hthallar8@gmail.com', '1234567890', '213', '2017-05-03 18:52:36'),
('Ht', 'hthallar8@gmail.com', '1234567890', '213', '2017-05-03 18:54:30'),
('Ht', 'hthallar8@gmail.com', '1234567890', '123', '2017-05-03 18:54:59'),
('Ht', 'hthallar8@gmail.com', '1234567890', '123', '2017-05-03 18:56:25'),
('Ht', 'hthallar8@gmail.com', '1234567890', '123', '2017-05-03 18:57:40'),
('Ht', 'hthallar8@gmail.com', '1234567890', '123', '2017-05-03 18:58:41'),
('Ht', 'hthallar8@gmail.com', '1234567890', '1', '2017-05-03 19:01:00'),
('Hardik', 'hthakkar8@gmail.com', '1234567890', '12132132321312', '2017-05-03 19:02:15'),
('Ht', 'hthallar8@gmail.com', '1234567890', '213', '2017-05-03 19:07:02'),
('Ht', 'hthallar8@gmail.com', '1234567890', '231', '2017-05-03 19:08:03'),
('Ht', 'hthallar8@gmail.com', '1234567890', '13', '2017-05-03 19:09:25'),
('h', 'hthallar8@gmail.com', '1234567890', 'dfs', '2017-05-03 19:13:28'),
('Ht', 'hthallar8@gmail.com', '1234567890', '55', '2017-05-03 19:14:25'),
('Ht', 'hthallar8@gmail.com1', '1234567890', '12', '2017-05-03 19:15:24'),
('Ht', 'hthallar8@gmail.com', '1234567890', 'Sucsdxsaxsa', '2017-05-03 19:16:08'),
('Ht', 'hthallar8@gmail.com1', '1234567890', '12', '2017-05-03 19:19:26'),
('Ht', 'hthallar8@gmail.com1', '1234567890', '213', '2017-05-03 19:21:57'),
('Ht', 'hthallar8@gmail.com1', '1234567890', '213', '2017-05-03 19:21:57'),
('Ht', 'hthallar8@gmail.com1', '1234567890', '131', '2017-05-03 19:26:33'),
('Ht', 'hthallar8@gmail.com1', '1234567890', '123', '2017-05-03 19:28:22'),
('Ht', 'hthallar8@gmail.com1', '1234567890', '2', '2017-05-03 19:32:03'),
('Ht', 'hthallar8@gmail.com1', '1234567890', '213', '2017-05-03 19:33:47'),
('Ht', 'hthallar8@gmail.com1', '1234567890', '12', '2017-05-03 19:35:12'),
('Ht', 'hthallar8@gmail.com1', '1234567890', '213', '2017-05-03 19:48:31'),
('Hardik', 'hthallar8@gmail.com', '1234567890', '11', '2017-05-07 11:43:33'),
('ht', 'hthallar8@gmail.com', '1234567890', '1', '2017-05-07 11:44:10'),
('Ht', 'hthallar8@gmail.com', '1234567890', 'Dd', '2017-05-07 11:44:55'),
('Ht', 'hthallar8@gmail.com', '1234567890', '2ws', '2017-06-02 17:14:53'),
('Ht', 'hthallar8@gmail.com', '1234567890', 'asd', '2017-06-02 17:39:49'),
('d', 'ds', 'wd', 'dsa', '2017-06-02 17:55:14'),
('fsd', 'adsa@da.com', '1234567891', '3131243', '2017-10-26 19:59:38'),
('Hardik', 'hthallar8@gmail.com', '8655645939', 'ad', '2017-10-26 20:04:47'),
('$name', '$email', '$phone.', '$comments', '2017-10-26 20:07:40');

-- --------------------------------------------------------

--
-- Table structure for table `personal_details`
--

CREATE TABLE `personal_details` (
  `id` int(11) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `userID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personal_details`
--

INSERT INTO `personal_details` (`id`, `first_name`, `last_name`, `userID`) VALUES
(1, 'Hardik', 'Thakkar', 4),
(2, 'ha', '1213', 11),
(3, 'dsf', 'afa', 12);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `vehicle` text NOT NULL,
  `slotDate` date NOT NULL,
  `slotTiming` varchar(20) NOT NULL,
  `transaction_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id`, `userID`, `vehicle`, `slotDate`, `slotTiming`, `transaction_time`) VALUES
(5, 4, 'BMW M 500000000', '2017-05-19', 'morning', '2017-05-26 07:45:21'),
(6, 4, 'HERO wdsa wddq', '2017-06-14', 'morning', '2017-06-02 11:39:54'),
(7, 4, 'HONDA AMZAe MH21Sd1234', '2017-06-22', 'evening', '2017-06-02 12:27:09'),
(8, 4, 'HONDA AMZAe MH21Sd1234', '2017-06-22', 'evening', '2017-06-02 12:27:19'),
(9, 4, 'HONDA AMZAe MH21Sd1234', '2017-06-10', 'evening', '2017-06-02 12:27:42'),
(10, 4, 'HERO wdsa wddq', '2017-06-15', 'evening', '2017-06-02 12:28:05'),
(11, 4, 'HERO wdsa wddq', '2017-06-15', 'evening', '2017-06-02 12:30:19'),
(12, 4, 'HONDA AMZAe MH21Sd1234', '2017-06-22', 'morning', '2017-06-02 12:31:00'),
(13, 4, 'HONDA AMZAe MH21Sd1234', '2017-06-15', 'afternoon', '2017-06-02 12:32:08'),
(14, 4, 'HERO wdsa wddq', '2017-06-14', 'evening', '2017-06-02 12:33:30'),
(15, 4, 'HERO wdsa wddq', '2017-06-03', 'evening', '2017-06-02 12:34:12'),
(16, 4, 'HERO wdsa wddq', '2017-06-07', 'afternoon', '2017-06-02 12:36:45'),
(17, 4, 'HERO wdsa wddq', '2017-07-07', 'morning', '2017-06-08 08:28:50'),
(18, 4, 'HERO wdsa wddq', '2017-07-07', 'morning', '2017-06-08 08:29:03'),
(19, 4, 'HONDA AMZAe MH21Sd1234', '2017-06-23', 'morning', '2017-06-08 08:52:37'),
(20, 4, 'HONDA AMZAe MH21Sd1234', '2017-06-16', 'afternoon', '2017-06-08 08:59:02'),
(21, 4, 'HONDA AMZAe MH21Sd1234', '2017-06-16', 'afternoon', '2017-06-08 08:59:13'),
(22, 4, 'HONDA AMZAe MH21Sd1234', '2017-06-19', 'evening', '2017-06-08 09:00:38'),
(23, 4, 'HERO wdsa wddq', '2017-06-23', 'morning', '2017-06-08 09:01:25'),
(24, 4, 'HERO wdsa wddq', '2017-10-24', 'afternoon', '2017-06-08 09:02:01'),
(25, 4, 'HONDA AMZAe MH21Sd1234', '2017-04-05', 'afternoon', '2017-06-08 09:03:26'),
(26, 4, 'HONDA AMZAe MH21Sd1234', '2017-06-23', 'evening', '2017-06-08 09:04:23'),
(27, 4, 'HONDA AMZAe MH21Sd1234', '2017-06-23', 'evening', '2017-06-08 09:04:28'),
(28, 4, 'HONDA AMZAe MH21Sd1234', '2017-04-05', 'evening', '2017-06-08 09:04:50'),
(29, 4, 'HERO wdsa wddq', '2017-06-22', 'afternoon', '2017-06-08 09:05:26'),
(30, 4, 'HONDA AMZAe MH21Sd1234', '2017-03-13', 'morning', '2017-06-08 09:05:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `phone`, `role`) VALUES
(4, 'ht', 'hthallar8@gmail.com', '$2y$10$Yuk7RmUxwa/KDMiJDPtmZeu1g9dhVT9XZ3qfEprn/XbGAE4aYuKxS', '1234567890', 'user'),
(5, 'ht1', 'ht12345@gnail.com', '$2y$10$rOoFGCrUX0qHimze.qbdGe7vz3fjlPLtMWR3p/oBnqg2SdvpTP3EG', '1234567891', 'user'),
(6, 'ht2', 'ht@gmail.com', '$2y$10$0c2ATDGPOXtKGBTF9t/BTuKygOjXIEZlbnkaUBkgoT.JMAzGnSO86', '1', 'user'),
(7, 'ht2', 'ht@gmail.com', '$2y$10$0c2ATDGPOXtKGBTF9t/BTuKygOjXIEZlbnkaUBkgoT.JMAzGnSO86', '1', 'user'),
(8, 'ht3', 'ht1@gmail.com', '$2y$10$OnyW9vtvK7jsYEzbRVrTdO/RiMXgZTsr0hOAnH8c3fce70N4P7d82', '1234567892', 'user'),
(9, 'ht4', 'ht21@gmail.com', '$2y$10$6IiLwM9HEUbA9cCtZItbS.PHZBKb4xocqHnNJtZAb1zajIB6ZwDoG', '1234567893', 'user'),
(10, 'ht43', '121@gmail.com', '$2y$10$FhLXlvEVh1vxcs.2Rw737uxPTDm35u0dya8hvigapFHGA5axl.BK.', '213', 'user'),
(11, 'newht', 'ht8@gmail.com', '$2y$10$Y3/7uyhCbQWXrxb.QS1tzeperFGFPYCW.my1LgVAl8NBcEKmx7h0O', '1234567899', 'user'),
(12, 'hhhh', 'da@gmail.com', '$2y$10$z.HfTsqFa3vR39oI8gi9...wx5tP76fK0Ttr.LpSe.HDvZ8KBOaMe', '12323', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `model` varchar(20) NOT NULL,
  `vehicle_number` varchar(20) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`id`, `brand`, `model`, `vehicle_number`, `uid`) VALUES
(7, 'HERO', 'wdsa', 'wddq', 4),
(8, 'HONDA', 'AMZAe', 'MH21Sd1234', 4),
(9, 'daddas', 'asdassa', 'asd', 4),
(10, 'rer', 'ewqe', 'qwreae', 11);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid_fk` (`uid`),
  ADD KEY `addr_type_fk` (`addresstype`);

--
-- Indexes for table `addresstype`
--
ALTER TABLE `addresstype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_details`
--
ALTER TABLE `personal_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userID_fk` (`userID`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trans_userID` (`userID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_fk` (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `addresstype`
--
ALTER TABLE `addresstype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `personal_details`
--
ALTER TABLE `personal_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `addr_type_fk` FOREIGN KEY (`addresstype`) REFERENCES `addresstype` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `uid_fk` FOREIGN KEY (`uid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `personal_details`
--
ALTER TABLE `personal_details`
  ADD CONSTRAINT `userID_fk` FOREIGN KEY (`userID`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `trans_userID` FOREIGN KEY (`userID`) REFERENCES `users` (`id`);

--
-- Constraints for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD CONSTRAINT `user_fk` FOREIGN KEY (`uid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
